package com.example.restspringboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/**
 * 
 * @author Robert Jenifer Vilbert
 * Mar 27, 2017 12:07:35 AM 12:07:35 AM 
 * Application.java
 */
@Configuration
@EnableAutoConfiguration
@ComponentScan("com.example.restspringboot.*")
public class RestSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestSpringBootApplication.class, args);
	}
}
